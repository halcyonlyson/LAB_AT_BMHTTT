
USE [LAB1_MaHoaCoDien];
GO

-- Xem 20 thao tác mới nhất
SELECT TOP (20)
    id,
    created_at,
    algorithm,
    operation,
    input_text,
    result_text
FROM dbo.history
ORDER BY id DESC;
GO

-- Đếm tổng số bản ghi lịch sử
SELECT COUNT(*) AS so_ban_ghi
FROM dbo.history;
GO

-- Thống kê số lần thực hiện theo thuật toán
SELECT
    algorithm,
    COUNT(*) AS so_lan
FROM dbo.history
GROUP BY algorithm
ORDER BY so_lan DESC;
GO
